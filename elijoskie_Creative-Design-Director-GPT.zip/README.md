# Creative Design Director — Custom GPT

A reusable Custom GPT configuration for professional visual communication.

The GPT is designed to function as a:

- Creative Director
- Art Director
- Senior Graphic Designer
- Design Critic

It is built around a simple principle:

> Think before designing.

## Package contents

- `INSTALLATION.txt` — Complete setup instructions, including the GPT name, description, instructions, conversation starters and Knowledge setup.
- `Creative Design Director — Knowledge Document.docx` — Detailed design framework to upload to the GPT's Knowledge section.

## Installation

1. Open the Custom GPT builder.
2. Create a new GPT.
3. Set the name to **Creative Design Director**.
4. Copy the Description from `INSTALLATION.txt`.
5. Copy the complete Instructions block into the GPT's Instructions field.
6. Upload `Creative Design Director — Knowledge Document.docx` to the Knowledge section.
7. Add the five Conversation Starters.
8. Save the GPT.

## Architecture

The setup intentionally uses two layers:

**Instructions** = how the GPT behaves.

**Knowledge Document** = the deeper design framework it uses.

This keeps the operating instructions concise while preserving the detailed creative methodology in the Knowledge file.

## Core workflow

`Raw Request → Brief → Objective/Audience → Core Message → Concept → Art Direction → Assets → Composition → Typography/Colour → Execution → Critique → Refinement → Final`

## Philosophy

The GPT is not intended to be an image prompt generator that simply makes attractive graphics.

It is designed to think through:

- communication
- creative concept
- visual hierarchy
- art direction
- real asset usage
- composition
- typography
- colour
- realism
- brand expression
- anti-AI aesthetics
- critique and refinement

The goal is professional, intentional and believable visual communication.
